import 'package:flutter/material.dart';
import 'class/AppFile.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Settings extends StatefulWidget {
  const Settings({Key? key}) : super(key: key);

  @override
  _SettingsState createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  SharedPreferences? prefs;
  int? count ;
  String? textField ;

  @override
  void initState() {

    void start() async {
      prefs = await SharedPreferences.getInstance();
      _getData();

    }
    start();

    super.initState();
  }

  _addText() async{
    await prefs?.setString('text', textField! );
    await prefs?.setInt('count', count! + 1  );
    _getData();
  }

  _getData() async{
    setState(() {
      count  = prefs?.getInt('count') ?? 0;
      textField = prefs?.getString('text') ?? '';
    });
  }

  _cleanData() async{
    await prefs?.setString('text', '' );
    await prefs?.setInt('count', 0  );
    _getData();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Row(
            children:<Widget>[
              Expanded(
                flex:1,
                child: GestureDetector(
                    onTap: (){
                      Navigator.pushNamed(context, '/');
                    },
                    child:Container(
                        child:Text(
                            'файл',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color:Colors.black
                            )
                        )
                    )
                ),
              ),
              Expanded(
                  flex:1,
                  child: GestureDetector(
                      onTap: (){
                        Navigator.pushNamed(context, '/second');
                      },
                      child:Container(
                          child:Text(
                            'бд',
                            style: TextStyle(
                                color:Colors.black
                            ),
                            textAlign: TextAlign.center,
                          )
                      )
                  )
              ),
              Expanded(
                  flex:1,
                  child: GestureDetector(
                      onTap: (){
                        Navigator.pushNamed(context, '/settings');
                      },
                      child:Container(
                          child:Text(
                              'настройки',
                              textAlign: TextAlign.center
                          )
                      )
                  )
              )
            ]
        ),
        centerTitle: true,
      ),
      body: Center(
          child: Column(
            children: [
              Container(
                height:30,
                margin: EdgeInsets.only(top:10),
                width: double.infinity,
                child: Text(
                  'НАСТРОЙКИ',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  height: 100,
                  margin: EdgeInsets.all(10),
                  padding: EdgeInsets.all(10),
                  width: double.infinity,
                  decoration: BoxDecoration(border: Border.all(width: 1)),
                  child: Text(
                    'count - $count -- text - $textField',
                    softWrap: true,
                  ),
                ),
              ),
              Flexible(
                  child: Container(
                    margin: EdgeInsets.all(10),
                    decoration:
                    BoxDecoration(border: Border.all(color: Colors.blue, width: 2)),
                    child: TextField(
                      onChanged: (text){
                        setState(() {
                          textField =  text;
                        });
                      },
                    ),
                  )),
              Expanded(
                  child:
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(
                      child: Container(
                        height: 100,
                        margin: EdgeInsets.only(top: 15, bottom: 15, left: 5, right: 5),
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.green, width: 1)),
                        child: Center(
                          child: TextButton(
                            onPressed:_addText,
                            child: Text('Добавить'),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        margin: EdgeInsets.only(top: 15, bottom: 15, left: 5, right: 5),
                        height: 100,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.green, width: 1)),
                        child: Center(
                          child: TextButton(
                            onPressed:(){},
                            child: Text('Получить'),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                        flex: 1,
                        child: Container(
                            margin:
                            EdgeInsets.only(top: 15, bottom: 15, left: 5, right: 5),
                            height: 100,
                            decoration: BoxDecoration(
                                border: Border.all(color: Colors.black, width: 1)),
                            child: Center(
                                child: TextButton(
                                    onPressed:_cleanData,
                                    child: Text('Удалить')))))
                  ]))
            ],
          )), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
