import 'package:flutter/material.dart';
import 'class/AppFile.dart';


class Second extends StatefulWidget {
  const Second({Key? key}) : super(key: key);

  @override
  _SecondState createState() => _SecondState();
}

class _SecondState extends State<Second> {
  String fileData = '';

  String savedData = '';

  String filePath = '';
  String directoryPath = '';

  AppFile appfile = AppFile();

  final _controller = TextEditingController();

  @override
  void initState() {
    _controller.text = '';

    _controller.addListener(() {
      fileData = _controller.text;
    });


   void start()async{
     var path = await appfile.getLocalPath;
     setState(() {
       filePath = path;
           print(filePath);
     });
   }


    _readLocalData();
    super.initState();
  }

  @override
  void dispose(){
    _controller.clear();
  }


  _readLocalData() async {
    var readFile = await appfile.readLocalFile();
    setState(() {
      savedData = readFile;
    });
  }

  _addData() async {
    var writeFile = await appfile.writeLocalFile(fileData);
    _readLocalData();
  }

  _cleanData() async {
    var writeFile = await appfile.writeLocalFile('');
    _controller.clear();
    setState(() {
      fileData = '';
    });
    _readLocalData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Row(
            children:<Widget>[
              Expanded(
                flex:1,
                child: GestureDetector(
                    onTap: (){
                      Navigator.pushNamed(context, '/');
                    },
                    child:Container(
                        child:Text(
                            'файл',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color:Colors.black
                            )
                        )
                    )
                ),
              ),
              Expanded(
                  flex:1,
                  child: GestureDetector(
                      onTap: (){
                        Navigator.pushNamed(context, '/second');
                      },
                      child:Container(
                          child:Text(
                            'бд',
                            textAlign: TextAlign.center,
                          )
                      )
                  )
              ),
              Expanded(
                  flex:1,
                  child: GestureDetector(
                      onTap: (){
                        Navigator.pushNamed(context, '/settings');
                      },
                      child:Container(
                          child:Text(
                            'настройки',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color:Colors.black
                            )
                          )
                      )
                  )
              )
            ]
        ),
        centerTitle: true,
      ),
      body: Center(
          child: Column(
            children: [
              Container(
                height:30,
                margin: EdgeInsets.only(top:10),
                width: double.infinity,
                child: Text(
                  'БАЗА ДАННЫХ',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  height: 100,
                  margin: EdgeInsets.all(10),
                  padding: EdgeInsets.all(10),
                  width: double.infinity,
                  decoration: BoxDecoration(border: Border.all(width: 1)),
                  child: Text(
                    savedData,
                    softWrap: true,
                  ),
                ),
              ),
              Flexible(
                  child: Container(
                    margin: EdgeInsets.all(10),
                    decoration:
                    BoxDecoration(border: Border.all(color: Colors.blue, width: 2)),
                    child: TextField(
                      onChanged: (text){
                        setState(() {
                          fileData = text;
                        });
                      },
                    ),
                  )),
              Expanded(
                  child:
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(
                      child: Container(
                        height: 100,
                        margin: EdgeInsets.only(top: 15, bottom: 15, left: 5, right: 5),
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.green, width: 1)),
                        child: Center(
                          child: TextButton(
                            onPressed: _addData,
                            child: Text('Добавить'),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        margin: EdgeInsets.only(top: 15, bottom: 15, left: 5, right: 5),
                        height: 100,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.green, width: 1)),
                        child: Center(
                          child: TextButton(
                            onPressed: _addData,
                            child: Text('Получить'),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                        flex: 1,
                        child: Container(
                            margin:
                            EdgeInsets.only(top: 15, bottom: 15, left: 5, right: 5),
                            height: 100,
                            decoration: BoxDecoration(
                                border: Border.all(color: Colors.black, width: 1)),
                            child: Center(
                                child: TextButton(
                                    onPressed: _cleanData, child: Text('Удалить')))))
                  ]))
            ],
          )), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
